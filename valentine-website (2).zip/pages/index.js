import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Play } from "lucide-react";

const options = ["Pretty please? 🥺", "Are you sure? 😢", "Think again! 🤔", "Last chance! 💔", "Okay... but really? 😭"];
const duduBubuGifs = [
  "https://media.tenor.com/YOUR_DUDU_BUBU_GIF_1.gif",
  "https://media.tenor.com/YOUR_DUDU_BUBU_GIF_2.gif",
  "https://media.tenor.com/YOUR_DUDU_BUBU_GIF_3.gif",
  "https://media.tenor.com/YOUR_DUDU_BUBU_GIF_4.gif",
  "https://media.tenor.com/YOUR_DUDU_BUBU_GIF_5.gif"
];

export default function ValentinePage() {
  const [hovered, setHovered] = useState(false);
  const [noClicks, setNoClicks] = useState(0);
  const musicUrl = "https://your-music-link.mp3"; // Replace with your desired song

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-pink-200 text-center p-4">
      <Card className="bg-white p-6 shadow-xl rounded-2xl max-w-md">
        <CardContent>
          <img src={duduBubuGifs[Math.min(noClicks, duduBubuGifs.length - 1)]} alt="Cute Dudu Bubu" className="w-40 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-pink-600">Will you be my Valentine? 💕</h1>
          <div className="mt-6 flex justify-center gap-4">
            <Button className="bg-red-500 text-white px-6 py-2 rounded-lg text-lg">YES! ❤️</Button>
            <motion.div
              onMouseEnter={() => setHovered(true)}
              onMouseLeave={() => setHovered(false)}
              animate={{ x: hovered ? 100 : 0 }}
            >
              <Button
                className="bg-gray-300 text-black px-6 py-2 rounded-lg text-lg"
                onClick={() => setNoClicks((prev) => prev + 1)}
              >
                {noClicks < options.length ? options[noClicks] : "You can't say no! 😆"}
              </Button>
            </motion.div>
          </div>
          <div className="mt-6">
            <Button className="bg-purple-500 text-white px-4 py-2 rounded-lg flex items-center gap-2" onClick={() => new Audio(musicUrl).play()}>
              <Play size={18} /> Play Romantic Music 🎶
            </Button>
          </div>
          <img src="https://media.tenor.com/YOUR_CAT_ANIMATION.gif" alt="Cute Cat" className="w-40 mx-auto mt-4" />
        </CardContent>
      </Card>
    </div>
  );
}